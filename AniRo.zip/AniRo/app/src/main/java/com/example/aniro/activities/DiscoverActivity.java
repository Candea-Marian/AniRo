package com.example.aniro.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apollographql.apollo.ApolloCall;
import com.apollographql.apollo.ApolloClient;
import com.apollographql.apollo.api.Response;
import com.apollographql.apollo.exception.ApolloException;
import com.example.aniro.FeedResultQuery;
import com.example.aniro.R;
import com.example.aniro.adapters.RecyclerViewAdapter;
import com.example.aniro.models.Anime;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import okhttp3.OkHttpClient;

public class DiscoverActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ApolloClient apolloClient;
    private static final String BASE_URL = "https://graphql.anilist.co";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover);

        final ArrayList<Anime> animeList = new ArrayList<>();

        final OkHttpClient okHttpClient = new OkHttpClient.Builder().build();

        apolloClient = ApolloClient.builder()
                .serverUrl(BASE_URL)
                .okHttpClient(okHttpClient)
                .build();

        apolloClient.query(FeedResultQuery.builder().build()).enqueue(new ApolloCall.Callback<FeedResultQuery.Data>() {
            @Override
            public void onResponse(@NotNull final Response<FeedResultQuery.Data> response) {
               DiscoverActivity.this.runOnUiThread(new Runnable() {
                   @Override
                   public void run() {
                        for(int i = 0; i < 50; i++) {
                            Anime anime = new Anime();
                            anime.setTitle(response.data().Page().media().get(i).title().romaji());
                            anime.setImage_url(response.data().Page().media().get(i).coverImage().large());

                            animeList.add(anime);
                        }

                       mRecyclerView = findViewById(R.id.recycler_view);
                       mRecyclerView.setHasFixedSize(true);
                       mLayoutManager = new LinearLayoutManager(getApplicationContext());
                       mAdapter = new RecyclerViewAdapter(animeList, getApplicationContext());

                       mRecyclerView.setLayoutManager(mLayoutManager);
                       mRecyclerView.setAdapter(mAdapter);
                       mRecyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
                   }
               });
            }

            @Override
            public void onFailure(@NotNull ApolloException e) {

            }
        });


    }
}
